export type Level = 'easy' | 'medium' | 'hard';
export type Difficulty = Level | 'mixed';

export interface Category {
  name: string;
  emoji: string;
  easy: string[];
  medium: string[];
  hard: string[];
}

export interface TeamSetup {
  name: string;
  players: number;
}

export interface Team {
  id: string;
  name: string;
  players: number;
  score: number;
  correct: number;
  skipped: number;
  rounds: number;
}

export type SkipMode = 'limited' | 'penalty' | 'free';

export interface Settings {
  teams: TeamSetup[];
  targetScore: number;
  roundSeconds: number;
  difficulty: Difficulty;
  categories: string[];
  sound: boolean;
  vibrate: boolean;
  skipMode: SkipMode;
  maxSkips: number;
}

export interface DrawnWord {
  word: string;
  category: string;
  emoji: string;
  level: Level;
}

export interface RoundEntry {
  word: string;
  category: string;
  correct: boolean;
}

export type Phase = 'setup' | 'ready' | 'playing' | 'paused' | 'roundEnd' | 'gameOver';

export interface GameState {
  phase: Phase;
  settings: Settings;
  teams: Team[];
  turnIndex: number;
  round: number;
  current: DrawnWord | null;
  used: string[];
  timeLeft: number;
  deadline: number | null;
  skipsUsed: number;
  roundLog: RoundEntry[];
  history: RoundEntry[];
  startedAt: number | null;
  playedMs: number;
  customWords: string[];
  winnerId: string | null;
}
