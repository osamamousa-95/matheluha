/* قصاصات احتفالية على Canvas بدون أي مكتبة خارجية. */

const COLORS = ['#F5B544', '#34D3A2', '#FF5C7A', '#8B6BFF', '#FFFFFF'];

interface Piece {
  x: number; y: number; vx: number; vy: number; size: number; rot: number; vr: number; color: string;
}

export function burstConfetti(canvas: HTMLCanvasElement, durationMs = 3500): () => void {
  const reduce = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const ctx = canvas.getContext('2d');
  if (!ctx) return () => {};

  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const resize = () => {
    canvas.width = canvas.clientWidth * dpr;
    canvas.height = canvas.clientHeight * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };
  resize();
  window.addEventListener('resize', resize);

  const w = () => canvas.clientWidth;
  const count = reduce ? 40 : 140;
  const pieces: Piece[] = Array.from({ length: count }, () => ({
    x: Math.random() * w(),
    y: -20 - Math.random() * canvas.clientHeight * 0.4,
    vx: (Math.random() - 0.5) * 1.6,
    vy: 1.6 + Math.random() * 2.6,
    size: 6 + Math.random() * 7,
    rot: Math.random() * Math.PI,
    vr: (Math.random() - 0.5) * 0.22,
    color: COLORS[Math.floor(Math.random() * COLORS.length)],
  }));

  let raf = 0;
  const end = performance.now() + durationMs;

  const frame = (now: number) => {
    ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
    for (const p of pieces) {
      p.x += p.vx; p.y += p.vy; p.rot += p.vr;
      if (p.y > canvas.clientHeight + 30 && now < end - 600) {
        p.y = -20; p.x = Math.random() * w();
      }
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
      ctx.restore();
    }
    if (now < end) raf = requestAnimationFrame(frame);
    else ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
  };
  raf = requestAnimationFrame(frame);

  return () => {
    cancelAnimationFrame(raf);
    window.removeEventListener('resize', resize);
    ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
  };
}
