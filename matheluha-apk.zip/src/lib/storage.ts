import type { GameState, Settings } from '../types';

const KEY = 'charades.ar.v1';

export interface Persisted {
  state?: GameState;
  settings?: Settings;
  lastGame?: GameState;
  theme?: 'light' | 'dark';
  customWords?: string[];
}

export function loadAll(): Persisted {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Persisted) : {};
  } catch {
    return {};
  }
}

export function saveAll(patch: Persisted): void {
  try {
    const next = { ...loadAll(), ...patch };
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* التخزين ممتلئ أو محجوب: اللعبة تكمل بدون حفظ */
  }
}

export function clearSaved(): void {
  try {
    const { settings, theme, customWords } = loadAll();
    localStorage.setItem(KEY, JSON.stringify({ settings, theme, customWords }));
  } catch {
    /* تجاهل */
  }
}
