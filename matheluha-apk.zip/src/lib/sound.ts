/* مؤثرات صوتية مولّدة بـ WebAudio: لا حاجة لأي ملفات صوت خارجية. */

type Cue = 'start' | 'correct' | 'skip' | 'tick' | 'timeup' | 'win' | 'tap';

let ctx: AudioContext | null = null;

function audio(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const AC = window.AudioContext || (window as any).webkitAudioContext;
  if (!AC) return null;
  if (!ctx) ctx = new AC();
  if (ctx.state === 'suspended') void ctx.resume();
  return ctx;
}

/** يجب استدعاؤها من أول لمسة للمستخدم حتى يسمح المتصفح بالصوت. */
export function unlockAudio(): void {
  audio();
}

function beep(freq: number, start: number, dur: number, gain = 0.16, type: OscillatorType = 'sine') {
  const ac = audio();
  if (!ac) return;
  const osc = ac.createOscillator();
  const vol = ac.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, ac.currentTime + start);
  vol.gain.setValueAtTime(0.0001, ac.currentTime + start);
  vol.gain.exponentialRampToValueAtTime(gain, ac.currentTime + start + 0.02);
  vol.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + start + dur);
  osc.connect(vol).connect(ac.destination);
  osc.start(ac.currentTime + start);
  osc.stop(ac.currentTime + start + dur + 0.05);
}

const PATTERNS: Record<Cue, () => void> = {
  start: () => { beep(523, 0, 0.12); beep(784, 0.12, 0.18); },
  correct: () => { beep(660, 0, 0.09); beep(990, 0.09, 0.16); },
  skip: () => { beep(320, 0, 0.12, 0.12, 'triangle'); },
  tick: () => { beep(880, 0, 0.05, 0.09, 'square'); },
  timeup: () => { beep(300, 0, 0.25, 0.18, 'sawtooth'); beep(200, 0.25, 0.35, 0.18, 'sawtooth'); },
  win: () => { [523, 659, 784, 1047].forEach((f, i) => beep(f, i * 0.13, 0.22)); },
  tap: () => { beep(700, 0, 0.04, 0.07); },
};

const VIBES: Record<Cue, number | number[]> = {
  start: 40, correct: [0, 35, 40, 35], skip: 25, tick: 12, timeup: [0, 120, 60, 120], win: [0, 90, 60, 90, 60, 180], tap: 10,
};

export function play(cue: Cue, opts: { sound: boolean; vibrate: boolean }): void {
  if (opts.sound) {
    try { PATTERNS[cue](); } catch { /* تجاهل */ }
  }
  if (opts.vibrate && typeof navigator !== 'undefined' && navigator.vibrate) {
    try { navigator.vibrate(VIBES[cue]); } catch { /* تجاهل */ }
  }
}
