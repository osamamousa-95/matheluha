import type { Level, WordCategory, WordPack } from '../types';
import { PACKS } from './loader';

export const LEVELS: Level[] = ['easy', 'medium', 'hard'];

export const CATEGORIES: WordCategory[] = PACKS.flatMap((p) =>
  p.categories.map((c) => ({ ...c, lang: c.lang ?? p.lang, packId: p.id }))
);

export const LANGUAGES: { code: string; name: string; packs: WordPack[] }[] = Object.values(
  PACKS.reduce<Record<string, { code: string; name: string; packs: WordPack[] }>>((acc, p) => {
    acc[p.lang] = acc[p.lang] ?? { code: p.lang, name: p.name, packs: [] };
    acc[p.lang].packs.push(p);
    return acc;
  }, {})
);

export function countWords(c: WordCategory): number {
  return LEVELS.reduce((n, l) => n + (c.words[l]?.length ?? 0), 0);
}

export const TOTAL_WORDS = CATEGORIES.reduce((n, c) => n + countWords(c), 0);

export const CATEGORY_BY_ID = new Map(CATEGORIES.map((c) => [c.id, c]));

/** يقبل معرّفات جديدة أو أسماء قديمة محفوظة من نسخة سابقة. */
export function normalizeCategoryIds(ids: string[]): string[] {
  const byName = new Map(CATEGORIES.map((c) => [c.name, c.id]));
  const out = ids.map((v) => (CATEGORY_BY_ID.has(v) ? v : byName.get(v))).filter(Boolean) as string[];
  return Array.from(new Set(out));
}
