import type { Category } from '../types';
import data from './words.json';

/**
 * قاعدة كلمات اللعبة: 26 تصنيفاً و 1499 كلمة، مقسّمة إلى سهل/متوسط/صعب.
 * لإضافة كلمات: افتح words.json وأضفها داخل التصنيف المناسب، أو أضف تصنيفاً جديداً
 * بنفس الشكل { name, emoji, easy, medium, hard }.
 */
export const CATEGORIES: Category[] = data as Category[];
