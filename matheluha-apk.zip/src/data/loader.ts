import type { WordPack } from '../types';

/**
 * كل ملف JSON داخل packs/ يصبح حزمة كلمات تلقائياً.
 * لإضافة لغة أو مجموعة كلمات جديدة: ضع ملفاً هنا فقط — لا تعديل على منطق اللعبة.
 */
const modules = import.meta.glob<{ default: WordPack }>('./packs/*.json', { eager: true });

export const PACKS: WordPack[] = Object.values(modules).map((m) => m.default ?? (m as unknown as WordPack));
