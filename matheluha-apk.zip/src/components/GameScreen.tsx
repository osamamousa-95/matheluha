import { useEffect, useRef } from 'react';
import type { Action } from '../hooks/useGame';
import type { GameState } from '../types';
import { play } from '../lib/sound';
import { CircularTimer } from './CircularTimer';
import { Scoreboard, teamColor } from './Scoreboard';
import {
  Btn,
  Card,
  IconCheck,
  IconPause,
  IconPlay,
  IconSkip,
  IconStop,
  cx,
} from './ui';

export function GameScreen({
  state,
  dispatch,
  onExit,
}: {
  state: GameState;
  dispatch: (a: Action) => void;
  onExit: () => void;
}) {
  const team = state.teams[state.turnIndex];
  const { sound, vibrate, skipMode, maxSkips, roundSeconds } = state.settings;
  const cue = { sound, vibrate };
  const skipsLeft = skipMode === 'limited' ? maxSkips - state.skipsUsed : Infinity;
  const playing = state.phase === 'playing';

  const begin = () => {
    play('start', cue);
    dispatch({ type: 'BEGIN', now: Date.now() });
  };
  const correct = () => {
    if (!playing) return;
    play('correct', cue);
    dispatch({ type: 'CORRECT' });
  };
  const skip = () => {
    if (!playing || skipsLeft <= 0) return;
    play('skip', cue);
    dispatch({ type: 'SKIP' });
  };
  const togglePause = () => {
    if (playing) dispatch({ type: 'PAUSE' });
    else if (state.phase === 'paused') dispatch({ type: 'RESUME', now: Date.now() });
  };

  /* صوت العد التنازلي في آخر خمس ثوانٍ ونهاية الوقت */
  const lastSec = useRef<number>(-1);
  useEffect(() => {
    if (!playing) return;
    const s = Math.ceil(state.timeLeft);
    if (s !== lastSec.current) {
      lastSec.current = s;
      if (s > 0 && s <= 5) play('tick', cue);
    }
  }, [state.timeLeft, playing]);

  const endedRef = useRef(false);
  useEffect(() => {
    if (state.phase === 'roundEnd' && !endedRef.current) {
      endedRef.current = true;
      play('timeup', cue);
    }
    if (state.phase !== 'roundEnd') endedRef.current = false;
  }, [state.phase]);

  /* اختصارات لوحة المفاتيح */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      if (e.code === 'Space' || e.code === 'Enter' || e.code === 'NumpadEnter') {
        e.preventDefault();
        if (state.phase === 'ready') begin();
        else if (playing) correct();
        else if (state.phase === 'roundEnd') dispatch({ type: 'NEXT_TURN' });
      } else if (e.key === 's' || e.key === 'ش' || e.code === 'ArrowLeft') {
        skip();
      } else if (e.key === 'p' || e.key === 'ط' || e.code === 'Escape') {
        togglePause();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  return (
    <div className="mx-auto flex min-h-[100dvh] w-full max-w-2xl flex-col px-4 pb-5 pt-3">
      <div className="flex items-center gap-3">
        <span className={cx('h-8 w-1.5 rounded-full', teamColor(state.turnIndex))} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-display text-2xl text-ink dark:text-white">{team.name}</p>
          <p className="text-sm text-ink/50 dark:text-white/45">
            الجولة {state.round} · {team.score} من {state.settings.targetScore}
          </p>
        </div>
        <Btn variant="ghost" className="px-3 py-2 text-sm" onClick={onExit}>
          خروج
        </Btn>
      </div>

      {state.phase === 'ready' && (
        <div className="flex flex-1 flex-col items-center justify-center gap-6 py-10 text-center">
          <div>
            <p className="text-ink/60 dark:text-white/55">استعدوا، الدور على</p>
            <h2 className="mt-2 font-display text-5xl text-ink dark:text-white">{team.name}</h2>
          </div>
          <Card className="w-full max-w-sm p-5 text-right">
            <ul className="space-y-1.5 text-ink/70 dark:text-white/60">
              <li>ممثل واحد يرى الكلمة، والباقي يخمّنون.</li>
              <li>لا كلام ولا إشارة لحروف الكلمة.</li>
              <li>
                {roundSeconds} ثانية ·{' '}
                {skipMode === 'limited'
                  ? `${maxSkips} تخطٍ مسموح`
                  : skipMode === 'penalty'
                    ? 'كل تخطٍ يخصم نقطة'
                    : 'التخطي مفتوح'}
              </li>
            </ul>
          </Card>
          <Btn variant="primary" className="w-full max-w-sm py-5 text-xl" onClick={begin}>
            <IconPlay className="h-6 w-6" />
            ابدأ الجولة
          </Btn>
        </div>
      )}

      {(playing || state.phase === 'paused') && (
        <div className="flex flex-1 flex-col">
          <div className="flex flex-1 flex-col items-center justify-center gap-6 py-6">
            <span className="rounded-full bg-black/5 px-4 py-2 text-sm text-ink/70 dark:bg-white/10 dark:text-white/70">
              {state.current?.emoji} {state.current?.category}
            </span>

            <Card
              key={state.current?.word}
              className={cx(
                'flex min-h-[9rem] w-full items-center justify-center px-6 py-10',
                'animate-card-in motion-reduce:animate-none',
                state.phase === 'paused' && 'blur-md select-none'
              )}
            >
              <p className="text-center font-display text-5xl leading-tight text-ink dark:text-white sm:text-6xl">
                {state.current?.word}
              </p>
            </Card>

            <CircularTimer
              timeLeft={state.timeLeft}
              total={roundSeconds}
              paused={state.phase === 'paused'}
              className="h-36 w-36"
            />

            <p className="text-sm text-ink/45 dark:text-white/40">
              {state.roundLog.filter((r) => r.correct).length} كلمة صحيحة في هذه الجولة
              {skipMode === 'limited' && ` · بقي ${Math.max(0, skipsLeft)} تخطٍ`}
            </p>
          </div>

          <div className="space-y-3">
            <Btn
              variant="success"
              className="w-full py-6 text-2xl"
              onClick={correct}
              disabled={!playing}
            >
              <IconCheck className="h-7 w-7" />
              تم التخمين
            </Btn>
            <div className="grid grid-cols-3 gap-3">
              <Btn variant="soft" onClick={skip} disabled={!playing || skipsLeft <= 0}>
                <IconSkip className="h-5 w-5" />
                تخطٍ
              </Btn>
              <Btn variant="soft" onClick={togglePause}>
                {playing ? <IconPause className="h-5 w-5" /> : <IconPlay className="h-5 w-5" />}
                {playing ? 'إيقاف' : 'استئناف'}
              </Btn>
              <Btn variant="danger" onClick={() => dispatch({ type: 'END_ROUND' })}>
                <IconStop className="h-5 w-5" />
                إنهاء
              </Btn>
            </div>
          </div>
        </div>
      )}

      {state.phase === 'roundEnd' && (
        <div className="flex flex-1 flex-col gap-5 py-6">
          <div className="text-center">
            <p className="text-ink/60 dark:text-white/55">انتهت جولة</p>
            <h2 className="mt-1 font-display text-4xl text-ink dark:text-white">{team.name}</h2>
            <p className="mt-3 font-display text-6xl text-mint">
              +{state.roundLog.filter((r) => r.correct).length}
            </p>
          </div>

          {state.roundLog.length > 0 && (
            <Card className="max-h-52 overflow-y-auto p-4">
              <ul className="space-y-2">
                {state.roundLog.map((r, i) => (
                  <li key={i} className="flex items-center gap-2 text-ink dark:text-white">
                    <span className={cx('text-lg', r.correct ? 'text-mint' : 'text-rose')}>
                      {r.correct ? '✓' : '↷'}
                    </span>
                    <span className="flex-1 truncate">{r.word}</span>
                    <span className="text-xs text-ink/40 dark:text-white/35">{r.category}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}

          <Card className="p-4">
            <Scoreboard
              teams={state.teams}
              target={state.settings.targetScore}
              activeIndex={state.turnIndex}
              compact
            />
          </Card>

          <Btn
            variant="primary"
            className="mt-auto w-full py-5 text-xl"
            onClick={() => dispatch({ type: 'NEXT_TURN' })}
          >
            الفريق التالي
          </Btn>
        </div>
      )}
    </div>
  );
}
