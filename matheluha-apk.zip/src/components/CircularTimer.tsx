import { cx } from './ui';

export function CircularTimer({
  timeLeft,
  total,
  paused,
  className,
}: {
  timeLeft: number;
  total: number;
  paused?: boolean;
  className?: string;
}) {
  const r = 52;
  const c = 2 * Math.PI * r;
  const ratio = total > 0 ? Math.max(0, Math.min(1, timeLeft / total)) : 0;
  const urgent = timeLeft <= 10;
  const seconds = Math.ceil(timeLeft);

  return (
    <div className={cx('relative', className)}>
      <svg viewBox="0 0 120 120" className="w-full h-full -rotate-90">
        <circle
          cx="60"
          cy="60"
          r={r}
          fill="none"
          strokeWidth="9"
          className="stroke-black/10 dark:stroke-white/10"
        />
        <circle
          cx="60"
          cy="60"
          r={r}
          fill="none"
          strokeWidth="9"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - ratio)}
          className={cx(
            'transition-[stroke-dashoffset] duration-100 ease-linear motion-reduce:transition-none',
            urgent ? 'stroke-rose' : 'stroke-gold'
          )}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span
          className={cx(
            'font-display text-4xl tabular-nums leading-none',
            urgent ? 'text-rose' : 'text-ink dark:text-white',
            urgent && !paused && 'animate-pulse-soft motion-reduce:animate-none'
          )}
        >
          {seconds}
        </span>
        <span className="mt-1 text-xs text-ink/50 dark:text-white/45">
          {paused ? 'متوقف' : 'ثانية'}
        </span>
      </div>
    </div>
  );
}
