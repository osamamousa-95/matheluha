import type { Team } from '../types';
import { cx, IconTrophy } from './ui';

const TEAM_COLORS = ['bg-violet', 'bg-gold', 'bg-mint', 'bg-rose', 'bg-sky', 'bg-orange'];

export function teamColor(index: number): string {
  return TEAM_COLORS[index % TEAM_COLORS.length];
}

export function Scoreboard({
  teams,
  target,
  activeIndex,
  compact,
}: {
  teams: Team[];
  target: number;
  activeIndex?: number;
  compact?: boolean;
}) {
  const top = Math.max(...teams.map((t) => t.score));
  return (
    <ul className={cx('space-y-2', compact && 'space-y-1.5')}>
      {teams.map((team, i) => {
        const leading = team.score === top && top > 0;
        return (
          <li
            key={team.id}
            className={cx(
              'flex items-center gap-3 rounded-2xl px-3 py-2.5 transition-colors',
              i === activeIndex
                ? 'bg-gold/15 ring-1 ring-gold/50'
                : 'bg-black/5 dark:bg-white/5'
            )}
          >
            <span className={cx('h-9 w-1.5 rounded-full', teamColor(i))} />
            <span className="flex-1 truncate font-semibold text-ink dark:text-white">
              {team.name}
              {leading && (
                <IconTrophy className="mr-1.5 inline-block w-4 h-4 text-gold align-[-2px]" />
              )}
            </span>
            {!compact && (
              <span className="text-xs text-ink/45 dark:text-white/40">
                {team.correct} صحيحة · {team.skipped} تخطٍ
              </span>
            )}
            <span className="font-display text-xl tabular-nums text-ink dark:text-white">
              {team.score}
              <span className="text-sm text-ink/40 dark:text-white/35">/{target}</span>
            </span>
          </li>
        );
      })}
    </ul>
  );
}
