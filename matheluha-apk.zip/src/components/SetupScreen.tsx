import { useMemo, useState } from 'react';
import { CATEGORIES, LEVELS, countWords } from '../data';
import type { Difficulty, Settings, SkipMode } from '../types';
import { ALL_CATEGORY_IDS, CUSTOM_CATEGORY_ID, CUSTOM_CATEGORY_NAME, TOTAL_WORDS, poolSize } from '../hooks/useGame';
import {
  Btn,
  Card,
  Chip,
  Field,
  IconPlay,
  IconPlus,
  IconSearch,
  IconSpark,
  IconX,
  Stepper,
  Switch,
  cx,
} from './ui';

const DURATIONS = [30, 60, 90, 120];
const DIFFICULTY_OPTIONS: { id: Difficulty; label: string }[] = [
  { id: 'easy', label: 'سهل' },
  { id: 'medium', label: 'متوسط' },
  { id: 'hard', label: 'صعب' },
  { id: 'mixed', label: 'عشوائي' },
];
const SKIP_MODES: { id: SkipMode; label: string }[] = [
  { id: 'limited', label: 'عدد محدود' },
  { id: 'penalty', label: 'بخصم نقطة' },
  { id: 'free', label: 'بلا قيود' },
];

export function SetupScreen({
  settings,
  setSettings,
  customWords,
  setCustomWords,
  onStart,
}: {
  settings: Settings;
  setSettings: (s: Settings) => void;
  customWords: string[];
  setCustomWords: (w: string[]) => void;
  onStart: () => void;
}) {
  const [query, setQuery] = useState('');
  const [draft, setDraft] = useState('');
  const [customDuration, setCustomDuration] = useState(settings.roundSeconds);

  const patch = (p: Partial<Settings>) => setSettings({ ...settings, ...p });

  const pool = useMemo(() => poolSize(settings, customWords), [settings, customWords]);

  const q = query.trim();
  const shown = useMemo(() => {
    if (!q) return CATEGORIES.map((c) => ({ cat: c, hits: 0 }));
    return CATEGORIES.map((c) => ({
      cat: c,
      hits: LEVELS.flatMap((l) => c.words[l] ?? []).filter((w) => w.includes(q)).length,
    })).filter(
      (x) =>
        x.cat.name.includes(q) ||
        (x.cat.themes ?? []).some((t) => t.includes(q)) ||
        x.hits > 0
    );
  }, [q]);

  const toggleCategory = (id: string) => {
    const on = settings.categories.includes(id);
    const next = on
      ? settings.categories.filter((c) => c !== id)
      : [...settings.categories, id];
    patch({ categories: next });
  };

  const setTeamCount = (n: number) => {
    const teams = [...settings.teams];
    while (teams.length < n) teams.push({ name: `الفريق ${teams.length + 1}`, players: 3 });
    teams.length = n;
    patch({ teams });
  };

  const addCustom = () => {
    const words = draft
      .split(/[,،\n]/)
      .map((w) => w.trim())
      .filter((w) => w.length > 0 && !customWords.includes(w));
    if (words.length === 0) return;
    const next = [...customWords, ...words];
    setCustomWords(next);
    setDraft('');
    if (!settings.categories.includes(CUSTOM_CATEGORY_ID)) {
      patch({ categories: [...settings.categories, CUSTOM_CATEGORY_ID] });
    }
  };

  return (
    <div className="mx-auto w-full max-w-2xl space-y-5 px-4 pb-28 pt-4">
      <header className="pt-2 text-center">
        <h1 className="font-display text-6xl leading-none text-ink dark:text-white sm:text-7xl">
          مَثِّلها
        </h1>
        <p className="mt-3 text-ink/60 dark:text-white/55">
          لعبة تمثيل الكلمات للعائلة والأصدقاء · {TOTAL_WORDS.toLocaleString('ar-EG')} كلمة في{' '}
          {CATEGORIES.length} تصنيفاً
        </p>
      </header>

      <Card className="space-y-5 p-5">
        <Field label="الفرق" hint={`${settings.teams.length} فرق`}>
          <Stepper value={settings.teams.length} min={2} max={6} onChange={setTeamCount} />
        </Field>

        <div className="space-y-2.5">
          {settings.teams.map((team, i) => (
            <div key={i} className="flex items-center gap-2">
              <input
                value={team.name}
                onChange={(e) => {
                  const teams = [...settings.teams];
                  teams[i] = { ...teams[i], name: e.target.value };
                  patch({ teams });
                }}
                placeholder={`الفريق ${i + 1}`}
                className="min-w-0 flex-1 rounded-2xl bg-black/5 px-4 py-3 font-semibold text-ink outline-none ring-gold/60 focus:ring-2 dark:bg-white/10 dark:text-white"
              />
              <div className="flex items-center gap-1 rounded-2xl bg-black/5 px-2 py-1.5 dark:bg-white/10">
                <button
                  type="button"
                  aria-label="لاعب أقل"
                  onClick={() => {
                    const teams = [...settings.teams];
                    teams[i] = { ...teams[i], players: Math.max(1, teams[i].players - 1) };
                    patch({ teams });
                  }}
                  className="px-2 text-lg text-ink/60 dark:text-white/60"
                >
                  −
                </button>
                <span className="w-10 text-center tabular-nums text-ink dark:text-white">
                  {team.players}
                </span>
                <button
                  type="button"
                  aria-label="لاعب أكثر"
                  onClick={() => {
                    const teams = [...settings.teams];
                    teams[i] = { ...teams[i], players: Math.min(20, teams[i].players + 1) };
                    patch({ teams });
                  }}
                  className="px-2 text-lg text-ink/60 dark:text-white/60"
                >
                  +
                </button>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="space-y-6 p-5">
        <Field label="نقاط الفوز">
          <Stepper
            value={settings.targetScore}
            min={3}
            max={60}
            onChange={(v) => patch({ targetScore: v })}
            suffix="نقطة"
          />
        </Field>

        <Field label="مدة الجولة">
          <div className="flex flex-wrap gap-2">
            {DURATIONS.map((d) => (
              <Chip
                key={d}
                active={settings.roundSeconds === d}
                onClick={() => patch({ roundSeconds: d })}
              >
                {d} ثانية
              </Chip>
            ))}
            <Chip
              active={!DURATIONS.includes(settings.roundSeconds)}
              onClick={() => patch({ roundSeconds: customDuration })}
            >
              مخصص
            </Chip>
          </div>
          {!DURATIONS.includes(settings.roundSeconds) && (
            <div className="pt-2">
              <Stepper
                value={settings.roundSeconds}
                min={10}
                max={300}
                step={5}
                suffix="ثانية"
                onChange={(v) => {
                  setCustomDuration(v);
                  patch({ roundSeconds: v });
                }}
              />
            </div>
          )}
        </Field>

        <Field label="مستوى الصعوبة">
          <div className="flex flex-wrap gap-2">
            {DIFFICULTY_OPTIONS.map((l) => (
              <Chip
                key={l.id}
                active={settings.difficulty === l.id}
                onClick={() => patch({ difficulty: l.id })}
              >
                {l.label}
              </Chip>
            ))}
          </div>
        </Field>

        <Field label="تخطي الكلمة">
          <div className="flex flex-wrap gap-2">
            {SKIP_MODES.map((m) => (
              <Chip
                key={m.id}
                active={settings.skipMode === m.id}
                onClick={() => patch({ skipMode: m.id })}
              >
                {m.label}
              </Chip>
            ))}
          </div>
          {settings.skipMode === 'limited' && (
            <div className="pt-2">
              <Stepper
                value={settings.maxSkips}
                min={1}
                max={10}
                suffix="مرات في الجولة"
                onChange={(v) => patch({ maxSkips: v })}
              />
            </div>
          )}
        </Field>
      </Card>

      <Card className="space-y-4 p-5">
        <Field label="التصنيفات" hint={`${pool.toLocaleString('ar-EG')} كلمة جاهزة`}>
          <div className="relative">
            <IconSearch className="pointer-events-none absolute right-3 top-3.5 h-5 w-5 text-ink/40 dark:text-white/40" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث عن تصنيف أو كلمة"
              className="w-full rounded-2xl bg-black/5 py-3 pr-11 pl-4 text-ink outline-none ring-gold/60 focus:ring-2 dark:bg-white/10 dark:text-white"
            />
          </div>
        </Field>

        <div className="flex gap-2">
          <Btn
            variant="ghost"
            className="px-3 py-2 text-sm"
            onClick={() => patch({ categories: ALL_CATEGORY_IDS })}
          >
            تحديد الكل
          </Btn>
          <Btn
            variant="ghost"
            className="px-3 py-2 text-sm"
            onClick={() => patch({ categories: [] })}
          >
            إلغاء التحديد
          </Btn>
        </div>

        <div className="flex flex-wrap gap-2">
          {shown.map(({ cat, hits }) => (
            <Chip
              key={cat.id}
              active={settings.categories.includes(cat.id)}
              onClick={() => toggleCategory(cat.id)}
            >
              <span className="ml-1">{cat.emoji}</span>
              {cat.name}
              <span className="opacity-60"> ({q && hits > 0 ? hits : countWords(cat)})</span>
            </Chip>
          ))}
          {customWords.length > 0 && (!q || CUSTOM_CATEGORY_NAME.includes(q)) && (
            <Chip
              active={settings.categories.includes(CUSTOM_CATEGORY_ID)}
              onClick={() => toggleCategory(CUSTOM_CATEGORY_ID)}
            >
              <span className="ml-1">✍️</span>
              {CUSTOM_CATEGORY_NAME} ({customWords.length})
            </Chip>
          )}
          {shown.length === 0 && (
            <p className="py-2 text-ink/50 dark:text-white/50">
              لا نتائج. جرّب كلمة أخرى، أو أضفها ككلمة مخصصة بالأسفل.
            </p>
          )}
        </div>
      </Card>

      <Card className="space-y-4 p-5">
        <Field label="كلماتك الخاصة" hint="افصل بينها بفاصلة أو سطر جديد">
          <div className="flex gap-2">
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addCustom()}
              placeholder="مثال: عرس، مقلوبة، دوار الجمارك"
              className="min-w-0 flex-1 rounded-2xl bg-black/5 px-4 py-3 text-ink outline-none ring-gold/60 focus:ring-2 dark:bg-white/10 dark:text-white"
            />
            <Btn variant="soft" onClick={addCustom} aria-label="أضف">
              <IconPlus className="h-5 w-5" />
            </Btn>
          </div>
        </Field>
        {customWords.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {customWords.map((w) => (
              <span
                key={w}
                className="inline-flex items-center gap-1.5 rounded-full bg-black/5 px-3 py-1.5 text-sm dark:bg-white/10"
              >
                {w}
                <button
                  type="button"
                  aria-label={`حذف ${w}`}
                  onClick={() => setCustomWords(customWords.filter((x) => x !== w))}
                  className="text-ink/40 hover:text-rose dark:text-white/40"
                >
                  <IconX className="h-3.5 w-3.5" />
                </button>
              </span>
            ))}
          </div>
        )}
      </Card>

      <Card className="space-y-3 p-5">
        <Switch
          label="المؤثرات الصوتية"
          checked={settings.sound}
          onChange={(v) => patch({ sound: v })}
        />
        <Switch label="الاهتزاز" checked={settings.vibrate} onChange={(v) => patch({ vibrate: v })} />
      </Card>

      <div
        className={cx(
          'fixed inset-x-0 bottom-0 z-20 border-t border-black/5 bg-paper/90 p-4 backdrop-blur',
          'dark:border-white/10 dark:bg-night/90'
        )}
      >
        <div className="mx-auto flex max-w-2xl items-center gap-3">
          <Btn
            variant="primary"
            className="flex-1 py-4 text-lg"
            onClick={onStart}
            disabled={pool === 0}
          >
            <IconPlay className="h-5 w-5" />
            {pool === 0 ? 'اختر تصنيفاً واحداً على الأقل' : 'ابدأ اللعب'}
          </Btn>
          <span className="hidden items-center gap-1.5 text-sm text-ink/50 dark:text-white/50 sm:flex">
            <IconSpark className="h-4 w-4 text-gold" />
            {pool.toLocaleString('ar-EG')} كلمة
          </span>
        </div>
      </div>
    </div>
  );
}
