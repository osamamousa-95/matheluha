import { useEffect, useRef } from 'react';
import type { GameState } from '../types';
import { burstConfetti } from '../lib/confetti';
import { play } from '../lib/sound';
import { teamColor } from './Scoreboard';
import { Btn, Card, IconPlay, IconTrophy, cx, formatClock } from './ui';

export function WinnerScreen({
  state,
  onReplay,
  onNewGame,
}: {
  state: GameState;
  onReplay: () => void;
  onNewGame: () => void;
}) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const winner = state.teams.find((t) => t.id === state.winnerId) ?? state.teams[0];
  const ranked = [...state.teams].sort((a, b) => b.score - a.score);
  const totalCorrect = state.teams.reduce((n, t) => n + t.correct, 0);
  const totalRounds = state.teams.reduce((n, t) => n + t.rounds, 0) + 1;

  useEffect(() => {
    play('win', { sound: state.settings.sound, vibrate: state.settings.vibrate });
    if (!canvas.current) return;
    return burstConfetti(canvas.current, 4000);
  }, []);

  const stats = [
    { label: 'الجولات', value: totalRounds },
    { label: 'الكلمات الصحيحة', value: totalCorrect },
    { label: 'وقت اللعب', value: formatClock(state.playedMs) },
  ];

  return (
    <div className="relative min-h-[100dvh]">
      <canvas
        ref={canvas}
        className="pointer-events-none fixed inset-0 z-10 h-full w-full"
        aria-hidden="true"
      />
      <div className="relative z-20 mx-auto flex min-h-[100dvh] w-full max-w-2xl flex-col gap-5 px-4 pb-6 pt-10">
        <div className="text-center">
          <IconTrophy className="mx-auto h-14 w-14 text-gold" />
          <p className="mt-4 text-ink/60 dark:text-white/55">الفوز من نصيب</p>
          <h1 className="mt-1 font-display text-5xl leading-tight text-ink dark:text-white sm:text-6xl">
            {winner.name}
          </h1>
          <p className="mt-2 font-display text-3xl text-gold">{winner.score} نقطة</p>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {stats.map((s) => (
            <Card key={s.label} className="p-4 text-center">
              <p className="font-display text-2xl tabular-nums text-ink dark:text-white">
                {s.value}
              </p>
              <p className="mt-1 text-xs text-ink/50 dark:text-white/45">{s.label}</p>
            </Card>
          ))}
        </div>

        <Card className="p-4">
          <ol className="space-y-2">
            {ranked.map((t, i) => (
              <li
                key={t.id}
                className={cx(
                  'flex items-center gap-3 rounded-2xl px-3 py-3',
                  i === 0 ? 'bg-gold/15' : 'bg-black/5 dark:bg-white/5'
                )}
              >
                <span className="w-5 text-center font-display text-lg text-ink/50 dark:text-white/45">
                  {i + 1}
                </span>
                <span
                  className={cx('h-8 w-1.5 rounded-full', teamColor(state.teams.indexOf(t)))}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold text-ink dark:text-white">{t.name}</p>
                  <p className="text-xs text-ink/45 dark:text-white/40">
                    {t.correct} صحيحة · {t.skipped} تخطٍ · {t.rounds} جولات · {t.players} لاعبين
                  </p>
                </div>
                <span className="font-display text-2xl tabular-nums text-ink dark:text-white">
                  {t.score}
                </span>
              </li>
            ))}
          </ol>
        </Card>

        <div className="mt-auto space-y-3">
          <Btn variant="primary" className="w-full py-5 text-xl" onClick={onReplay}>
            <IconPlay className="h-5 w-5" />
            إعادة اللعب بنفس الفرق
          </Btn>
          <Btn variant="soft" className="w-full py-4" onClick={onNewGame}>
            لعبة جديدة بإعدادات أخرى
          </Btn>
        </div>
      </div>
    </div>
  );
}
