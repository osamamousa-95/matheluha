import { useEffect, useState } from 'react';

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

/* ===== الأيقونات ===== */
type IconProps = { className?: string };
const svg = (path: React.ReactNode, extra?: Record<string, string>) =>
  function Icon({ className = 'w-5 h-5' }: IconProps) {
    return (
      <svg
        className={className}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={1.9}
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
        {...extra}
      >
        {path}
      </svg>
    );
  };

export const IconPlay = svg(<polygon points="6 4 20 12 6 20 6 4" fill="currentColor" stroke="none" />);
export const IconPause = svg(<><rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none" /><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none" /></>);
export const IconCheck = svg(<polyline points="20 6 10 18 4 12" />);
export const IconSkip = svg(<><polyline points="15 5 8 12 15 19" /><line x1="19" y1="5" x2="19" y2="19" /></>);
export const IconStop = svg(<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" stroke="none" />);
export const IconSun = svg(<><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>);
export const IconMoon = svg(<path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z" />);
export const IconTrophy = svg(<><path d="M8 4h8v5a4 4 0 01-8 0V4z" /><path d="M8 6H5v1a3 3 0 003 3M16 6h3v1a3 3 0 01-3 3" /><path d="M12 13v4M9 21h6M10 17h4" /></>);
export const IconUsers = svg(<><circle cx="9" cy="8" r="3" /><path d="M3 20a6 6 0 0112 0" /><path d="M16 6a3 3 0 010 6M17 20a6 6 0 00-2-4.5" /></>);
export const IconTimer = svg(<><circle cx="12" cy="13" r="8" /><path d="M12 9v4l2 2M9 2h6" /></>);
export const IconPlus = svg(<><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></>);
export const IconMinus = svg(<line x1="5" y1="12" x2="19" y2="12" />);
export const IconShuffle = svg(<><path d="M3 6h4l10 12h4" /><path d="M3 18h4l3-3.5" /><path d="M17 3l3 3-3 3M17 15l3 3-3 3" /></>);
export const IconSearch = svg(<><circle cx="11" cy="11" r="7" /><line x1="16.5" y1="16.5" x2="21" y2="21" /></>);
export const IconX = svg(<><line x1="6" y1="6" x2="18" y2="18" /><line x1="18" y1="6" x2="6" y2="18" /></>);
export const IconSpark = svg(<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z" />);
export const IconBack = svg(<polyline points="9 6 15 12 9 18" />);

/* ===== العناصر ===== */
type Variant = 'primary' | 'success' | 'danger' | 'ghost' | 'soft';

const VARIANTS: Record<Variant, string> = {
  primary: 'bg-gold text-night hover:bg-gold-deep active:bg-gold-deep shadow-glow',
  success: 'bg-mint text-night hover:brightness-95 active:brightness-90',
  danger: 'bg-rose text-white hover:brightness-95',
  soft: 'bg-black/5 dark:bg-white/10 text-ink dark:text-white hover:bg-black/10 dark:hover:bg-white/20',
  ghost: 'bg-transparent text-ink/70 dark:text-white/70 hover:bg-black/5 dark:hover:bg-white/10',
};

export function Btn({
  variant = 'soft',
  className,
  children,
  ...rest
}: { variant?: Variant } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      className={cx(
        'inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3 font-semibold',
        'transition-transform duration-150 active:scale-[0.97] disabled:opacity-40 disabled:pointer-events-none',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold focus-visible:ring-offset-2',
        'focus-visible:ring-offset-paper dark:focus-visible:ring-offset-night',
        VARIANTS[variant],
        className
      )}
    >
      {children}
    </button>
  );
}

export function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div
      className={cx(
        'rounded-3xl bg-white/90 dark:bg-surface/90 backdrop-blur',
        'border border-black/5 dark:border-white/10 shadow-card',
        className
      )}
    >
      {children}
    </div>
  );
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-baseline justify-between gap-3">
        <span className="font-semibold text-ink dark:text-white">{label}</span>
        {hint && <span className="text-sm text-ink/50 dark:text-white/45">{hint}</span>}
      </div>
      {children}
    </div>
  );
}

export function Stepper({
  value,
  min = 1,
  max = 99,
  step = 1,
  onChange,
  suffix,
}: {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (v: number) => void;
  suffix?: string;
}) {
  const set = (v: number) => onChange(Math.min(max, Math.max(min, v)));
  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        aria-label="إنقاص"
        onClick={() => set(value - step)}
        className="w-11 h-11 rounded-xl bg-black/5 dark:bg-white/10 flex items-center justify-center active:scale-95 transition"
      >
        <IconMinus className="w-5 h-5" />
      </button>
      <div className="min-w-[5rem] text-center font-display text-2xl tabular-nums">
        {value}
        {suffix && <span className="text-base font-sans text-ink/50 dark:text-white/50"> {suffix}</span>}
      </div>
      <button
        type="button"
        aria-label="زيادة"
        onClick={() => set(value + step)}
        className="w-11 h-11 rounded-xl bg-black/5 dark:bg-white/10 flex items-center justify-center active:scale-95 transition"
      >
        <IconPlus className="w-5 h-5" />
      </button>
    </div>
  );
}

export function Switch({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between gap-4 rounded-2xl bg-black/5 dark:bg-white/5 px-4 py-3"
    >
      <span className="font-medium text-ink dark:text-white">{label}</span>
      <span
        className={cx(
          'relative h-7 w-12 shrink-0 rounded-full transition-colors',
          checked ? 'bg-mint' : 'bg-black/20 dark:bg-white/20'
        )}
      >
        <span
          className={cx(
            'absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all',
            checked ? 'right-1' : 'right-6'
          )}
        />
      </span>
    </button>
  );
}

export function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cx(
        'rounded-full px-3.5 py-2 text-sm font-medium transition-all active:scale-95',
        active
          ? 'bg-gold text-night'
          : 'bg-black/5 dark:bg-white/10 text-ink/70 dark:text-white/60'
      )}
    >
      {children}
    </button>
  );
}

export function useTheme(initial: 'light' | 'dark') {
  const [theme, setTheme] = useState<'light' | 'dark'>(initial);
  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', theme === 'dark');
    root.style.colorScheme = theme;
  }, [theme]);
  return { theme, setTheme, toggle: () => setTheme((t) => (t === 'dark' ? 'light' : 'dark')) };
}

export function ThemeToggle({ theme, toggle }: { theme: 'light' | 'dark'; toggle: () => void }) {
  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={theme === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}
      className="w-11 h-11 rounded-xl bg-black/5 dark:bg-white/10 flex items-center justify-center active:scale-95 transition"
    >
      {theme === 'dark' ? <IconSun className="w-5 h-5" /> : <IconMoon className="w-5 h-5" />}
    </button>
  );
}

export function formatClock(ms: number): string {
  const total = Math.round(ms / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}
