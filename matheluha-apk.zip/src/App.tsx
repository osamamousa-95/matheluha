import { useEffect, useState } from 'react';
import { DEFAULT_SETTINGS, useGame } from './hooks/useGame';
import { loadAll, saveAll } from './lib/storage';
import { unlockAudio } from './lib/sound';
import type { Settings } from './types';
import { GameScreen } from './components/GameScreen';
import { SetupScreen } from './components/SetupScreen';
import { WinnerScreen } from './components/WinnerScreen';
import { Btn, IconShuffle, ThemeToggle, useTheme } from './components/ui';

export function App() {
  const [saved] = useState(() => loadAll());
  const { state, dispatch, startGame, resumable, resume, discardSaved } = useGame();
  const [settings, setSettings] = useState<Settings>(saved.settings ?? DEFAULT_SETTINGS);
  const [customWords, setCustomWords] = useState<string[]>(saved.customWords ?? []);
  const [note, setNote] = useState<string | null>(null);
  const { theme, toggle } = useTheme(saved.theme ?? 'dark');

  useEffect(() => saveAll({ theme }), [theme]);
  useEffect(() => {
    const unlock = () => unlockAudio();
    window.addEventListener('pointerdown', unlock, { once: true });
    return () => window.removeEventListener('pointerdown', unlock);
  }, []);
  useEffect(() => {
    if (!note) return;
    const id = setTimeout(() => setNote(null), 2200);
    return () => clearTimeout(id);
  }, [note]);

  if (state.phase === 'gameOver') {
    return (
      <WinnerScreen
        state={state}
        onReplay={() => dispatch({ type: 'REPLAY' })}
        onNewGame={() => dispatch({ type: 'NEW_GAME' })}
      />
    );
  }

  if (state.phase !== 'setup') {
    return (
      <GameScreen state={state} dispatch={dispatch} onExit={() => dispatch({ type: 'NEW_GAME' })} />
    );
  }

  return (
    <div className="min-h-[100dvh]">
      <div className="mx-auto flex w-full max-w-2xl items-center justify-end gap-2 px-4 pt-4">
        <Btn
          variant="ghost"
          className="px-3 py-2 text-sm"
          onClick={() => {
            dispatch({ type: 'SHUFFLE' });
            setNote('تم خلط الكلمات من جديد');
          }}
        >
          <IconShuffle className="h-4 w-4" />
          خلط الكلمات
        </Btn>
        <ThemeToggle theme={theme} toggle={toggle} />
      </div>

      {resumable && (
        <div className="mx-auto w-full max-w-2xl px-4 pt-4">
          <div className="flex flex-wrap items-center gap-3 rounded-3xl border border-gold/40 bg-gold/10 p-4">
            <p className="flex-1 text-ink dark:text-white">
              لديك لعبة غير منتهية — الجولة {resumable.round}.
            </p>
            <Btn variant="primary" className="px-4 py-2.5" onClick={resume}>
              أكمل اللعبة
            </Btn>
            <Btn variant="ghost" className="px-3 py-2.5" onClick={discardSaved}>
              تجاهل
            </Btn>
          </div>
        </div>
      )}

      {!resumable && saved.lastGame && (
        <div className="mx-auto w-full max-w-2xl px-4 pt-4">
          <div className="flex flex-wrap items-center gap-3 rounded-3xl bg-black/5 p-4 dark:bg-white/5">
            <p className="flex-1 text-ink/70 dark:text-white/60">
              آخر لعبة: {saved.lastGame.teams.map((t) => `${t.name} ${t.score}`).join(' · ')}
            </p>
            <Btn
              variant="soft"
              className="px-4 py-2.5"
              onClick={() => {
                const last = saved.lastGame!;
                setSettings(last.settings);
                setCustomWords(last.customWords);
                startGame(last.settings, last.customWords);
              }}
            >
              أعدها بنفس الإعدادات
            </Btn>
          </div>
        </div>
      )}

      <SetupScreen
        settings={settings}
        setSettings={setSettings}
        customWords={customWords}
        setCustomWords={setCustomWords}
        onStart={() => {
          unlockAudio();
          startGame(settings, customWords);
        }}
      />

      {note && (
        <div className="fixed bottom-24 left-1/2 z-30 -translate-x-1/2 rounded-full bg-ink px-5 py-3 text-sm text-white shadow-card dark:bg-white dark:text-ink">
          {note}
        </div>
      )}
    </div>
  );
}
