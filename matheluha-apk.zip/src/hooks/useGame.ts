import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { CATEGORIES } from '../data/words';
import type { DrawnWord, GameState, Level, Settings, Team } from '../types';
import { clearSaved, loadAll, saveAll } from '../lib/storage';

export const CUSTOM_CATEGORY = 'كلمات مخصصة';

export const ALL_CATEGORIES = CATEGORIES.map((c) => c.name);

export const TOTAL_WORDS = CATEGORIES.reduce(
  (n, c) => n + c.easy.length + c.medium.length + c.hard.length,
  0
);

export const DEFAULT_SETTINGS: Settings = {
  teams: [
    { name: 'الفريق الأزرق', players: 3 },
    { name: 'الفريق الذهبي', players: 3 },
  ],
  targetScore: 15,
  roundSeconds: 60,
  difficulty: 'mixed',
  categories: ALL_CATEGORIES,
  sound: true,
  vibrate: true,
  skipMode: 'limited',
  maxSkips: 3,
};

/** كل الكلمات المتاحة حسب التصنيفات والصعوبة المختارة. */
export function buildPool(settings: Settings, customWords: string[]): DrawnWord[] {
  const levels: Level[] =
    settings.difficulty === 'mixed' ? ['easy', 'medium', 'hard'] : [settings.difficulty];
  const pool: DrawnWord[] = [];
  for (const cat of CATEGORIES) {
    if (!settings.categories.includes(cat.name)) continue;
    for (const level of levels) {
      for (const word of cat[level]) {
        pool.push({ word, category: cat.name, emoji: cat.emoji, level });
      }
    }
  }
  if (settings.categories.includes(CUSTOM_CATEGORY)) {
    for (const word of customWords) {
      pool.push({ word, category: CUSTOM_CATEGORY, emoji: '✍️', level: 'medium' });
    }
  }
  return pool;
}

function makeTeams(settings: Settings): Team[] {
  return settings.teams.map((t, i) => ({
    id: `t${i}`,
    name: t.name.trim() || `الفريق ${i + 1}`,
    players: t.players,
    score: 0,
    correct: 0,
    skipped: 0,
    rounds: 0,
  }));
}

/** يسحب كلمة جديدة دون تكرار، ويعيد خلط المخزون تلقائياً عند استهلاكه. */
function drawNext(state: GameState): { word: DrawnWord | null; used: string[] } {
  const pool = buildPool(state.settings, state.customWords);
  if (pool.length === 0) return { word: null, used: [] };
  const used = new Set(state.used);
  let available = pool.filter((p) => !used.has(p.word));
  let nextUsed = state.used;
  if (available.length === 0) {
    available = pool;
    nextUsed = [];
  }
  const word = available[Math.floor(Math.random() * available.length)];
  return { word, used: [...nextUsed, word.word] };
}

export function initialState(settings: Settings, customWords: string[]): GameState {
  return {
    phase: 'setup',
    settings,
    teams: makeTeams(settings),
    turnIndex: 0,
    round: 1,
    current: null,
    used: [],
    timeLeft: settings.roundSeconds,
    deadline: null,
    skipsUsed: 0,
    roundLog: [],
    history: [],
    startedAt: null,
    playedMs: 0,
    customWords,
    winnerId: null,
  };
}

export type Action =
  | { type: 'START'; settings: Settings; customWords: string[] }
  | { type: 'BEGIN'; now: number }
  | { type: 'PAUSE' }
  | { type: 'RESUME'; now: number }
  | { type: 'TICK'; now: number }
  | { type: 'CORRECT' }
  | { type: 'SKIP' }
  | { type: 'END_ROUND' }
  | { type: 'NEXT_TURN' }
  | { type: 'REPLAY' }
  | { type: 'NEW_GAME' }
  | { type: 'RESTORE'; state: GameState }
  | { type: 'SHUFFLE' }
  | { type: 'SET_CUSTOM'; words: string[] };

export function reducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case 'START': {
      const base = initialState(action.settings, action.customWords);
      return { ...base, phase: 'ready', used: state.used, startedAt: Date.now() };
    }

    case 'BEGIN': {
      const { word, used } = drawNext(state);
      return {
        ...state,
        phase: 'playing',
        current: word,
        used,
        roundLog: [],
        skipsUsed: 0,
        timeLeft: state.settings.roundSeconds,
        deadline: action.now + state.settings.roundSeconds * 1000,
        startedAt: state.startedAt ?? Date.now(),
      };
    }

    case 'PAUSE':
      return state.phase === 'playing' ? { ...state, phase: 'paused', deadline: null } : state;

    case 'RESUME':
      return state.phase === 'paused'
        ? { ...state, phase: 'playing', deadline: action.now + state.timeLeft * 1000 }
        : state;

    case 'TICK': {
      if (state.phase !== 'playing' || state.deadline === null) return state;
      const left = Math.max(0, (state.deadline - action.now) / 1000);
      if (left <= 0) return reducer({ ...state, timeLeft: 0 }, { type: 'END_ROUND' });
      return { ...state, timeLeft: left };
    }

    case 'CORRECT': {
      if (state.phase !== 'playing' || !state.current) return state;
      const teams = state.teams.map((t, i) =>
        i === state.turnIndex ? { ...t, score: t.score + 1, correct: t.correct + 1 } : t
      );
      const entry = { word: state.current.word, category: state.current.category, correct: true };
      const team = teams[state.turnIndex];
      const won = team.score >= state.settings.targetScore;
      const base = {
        ...state,
        teams,
        roundLog: [...state.roundLog, entry],
        history: [...state.history, entry],
      };
      if (won) {
        return {
          ...base,
          phase: 'gameOver',
          winnerId: team.id,
          deadline: null,
          current: null,
          playedMs: state.startedAt ? Date.now() - state.startedAt : state.playedMs,
        };
      }
      const { word, used } = drawNext(base);
      return { ...base, current: word, used };
    }

    case 'SKIP': {
      if (state.phase !== 'playing' || !state.current) return state;
      const { skipMode, maxSkips } = state.settings;
      if (skipMode === 'limited' && state.skipsUsed >= maxSkips) return state;
      const teams = state.teams.map((t, i) =>
        i === state.turnIndex
          ? {
              ...t,
              skipped: t.skipped + 1,
              score: skipMode === 'penalty' ? Math.max(0, t.score - 1) : t.score,
            }
          : t
      );
      const entry = { word: state.current.word, category: state.current.category, correct: false };
      const base = {
        ...state,
        teams,
        skipsUsed: state.skipsUsed + 1,
        roundLog: [...state.roundLog, entry],
        history: [...state.history, entry],
      };
      const { word, used } = drawNext(base);
      return { ...base, current: word, used };
    }

    case 'END_ROUND': {
      if (state.phase !== 'playing' && state.phase !== 'paused') return state;
      const teams = state.teams.map((t, i) =>
        i === state.turnIndex ? { ...t, rounds: t.rounds + 1 } : t
      );
      return { ...state, phase: 'roundEnd', teams, deadline: null, timeLeft: 0 };
    }

    case 'NEXT_TURN': {
      const turnIndex = (state.turnIndex + 1) % state.teams.length;
      return {
        ...state,
        phase: 'ready',
        turnIndex,
        round: turnIndex === 0 ? state.round + 1 : state.round,
        current: null,
        roundLog: [],
        skipsUsed: 0,
        timeLeft: state.settings.roundSeconds,
        deadline: null,
      };
    }

    case 'REPLAY': {
      const base = initialState(state.settings, state.customWords);
      return { ...base, phase: 'ready', used: state.used, startedAt: Date.now() };
    }

    case 'NEW_GAME':
      return { ...initialState(state.settings, state.customWords), used: state.used };

    case 'RESTORE':
      return action.state.phase === 'playing'
        ? { ...action.state, phase: 'paused', deadline: null }
        : action.state;

    case 'SHUFFLE':
      return { ...state, used: [] };

    case 'SET_CUSTOM':
      return { ...state, customWords: action.words };

    default:
      return state;
  }
}

export function useGame() {
  const saved = useMemo(() => loadAll(), []);
  const [state, dispatch] = useReducer(
    reducer,
    initialState(saved.settings ?? DEFAULT_SETTINGS, saved.customWords ?? [])
  );
  const [resumable, setResumable] = useState<GameState | null>(
    saved.state && saved.state.phase !== 'setup' && saved.state.phase !== 'gameOver'
      ? saved.state
      : null
  );

  // المؤقت
  const raf = useRef<number | null>(null);
  useEffect(() => {
    if (state.phase !== 'playing') return;
    let alive = true;
    const loop = () => {
      if (!alive) return;
      dispatch({ type: 'TICK', now: Date.now() });
      raf.current = window.setTimeout(loop, 100) as unknown as number;
    };
    loop();
    return () => {
      alive = false;
      if (raf.current) clearTimeout(raf.current);
    };
  }, [state.phase]);

  // الحفظ التلقائي
  useEffect(() => {
    if (state.phase === 'setup') return;
    saveAll({
      state: { ...state, deadline: null },
      settings: state.settings,
      customWords: state.customWords,
      ...(state.phase === 'gameOver' ? { lastGame: state } : {}),
    });
    // متعمّد: لا نحفظ مع كل نبضة مؤقت، بل عند تغيّر مجريات اللعبة فقط
  }, [state.phase, state.round, state.turnIndex, state.teams, state.skipsUsed, state.used.length]);

  const startGame = useCallback((settings: Settings, customWords: string[]) => {
    setResumable(null);
    clearSaved();
    saveAll({ settings, customWords });
    dispatch({ type: 'START', settings, customWords });
  }, []);

  const resume = useCallback(() => {
    if (!resumable) return;
    dispatch({ type: 'RESTORE', state: resumable });
    setResumable(null);
  }, [resumable]);

  const discardSaved = useCallback(() => {
    setResumable(null);
    clearSaved();
  }, []);

  return { state, dispatch, startGame, resumable, resume, discardSaved };
}
