import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource/changa/600.css';
import '@fontsource/changa/700.css';
import '@fontsource/changa/800.css';
import '@fontsource/tajawal/400.css';
import '@fontsource/tajawal/500.css';
import '@fontsource/tajawal/700.css';
import { App } from './App';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

/* التخزين المؤقت للويب فقط؛ داخل تطبيق أندرويد الملفات محلية أصلاً. */
if ('serviceWorker' in navigator && !(window as any).Capacitor && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}
