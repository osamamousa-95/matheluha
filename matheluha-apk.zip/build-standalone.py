#!/usr/bin/env python3
"""يبني نسخة ملف واحد (HTML) من نفس شيفرة المشروع، تعمل بالنقر المزدوج بدون أي تثبيت."""
import json, re, sys, pathlib

ROOT = pathlib.Path(__file__).parent
ORDER = [
    "src/types.ts",
    "src/lib/storage.ts",
    "src/lib/sound.ts",
    "src/lib/confetti.ts",
    "src/hooks/useGame.ts",
    "src/components/ui.tsx",
    "src/components/CircularTimer.tsx",
    "src/components/Scoreboard.tsx",
    "src/components/SetupScreen.tsx",
    "src/components/GameScreen.tsx",
    "src/components/WinnerScreen.tsx",
    "src/App.tsx",
]

IMPORT_RE = re.compile(r"^import[\s\S]*?from\s+'[^']+';\s*$", re.M)
EXPORT_RE = re.compile(r"^export\s+(?=(const|function|interface|type|class|enum))", re.M)


def source() -> str:
    parts = []
    for rel in ORDER:
        code = (ROOT / rel).read_text(encoding="utf-8")
        code = IMPORT_RE.sub("", code)
        code = EXPORT_RE.sub("", code)
        parts.append(f"/* ===== {rel} ===== */\n{code.strip()}\n")
    return "\n".join(parts)


def words_json() -> str:
    raw = json.loads((ROOT / "src/data/words.json").read_text(encoding="utf-8"))
    return json.dumps(raw, ensure_ascii=False, separators=(",", ":"))


def main() -> None:
    theme = json.dumps(json.loads((ROOT / "tailwind.theme.json").read_text(encoding="utf-8")),
                       ensure_ascii=False, indent=2)
    css = (ROOT / "src/index.css").read_text(encoding="utf-8").replace("@tailwind base;", "") \
        .replace("@tailwind components;", "").replace("@tailwind utilities;", "").strip()
    html = (ROOT / "standalone.template.html").read_text(encoding="utf-8")
    html = html.replace("/*__THEME__*/", theme)
    html = html.replace("/*__CSS__*/", css)
    html = html.replace("/*__WORDS__*/", words_json())
    html = html.replace("/*__APP__*/", source())
    out = ROOT / "dist-standalone" / "matheluha.html"
    out.parent.mkdir(exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"تم: {out} ({out.stat().st_size // 1024} كيلوبايت)")


if __name__ == "__main__":
    sys.exit(main())
