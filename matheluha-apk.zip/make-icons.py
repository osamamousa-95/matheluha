#!/usr/bin/env python3
"""يولّد أيقونات اللعبة (PWA + أندرويد) بلا أي ملفات خارجية."""
from PIL import Image, ImageDraw
import pathlib, math

NIGHT = (21, 14, 36, 255)
GOLD = (245, 181, 68, 255)
PAPER = (242, 237, 251, 255)
OUT = pathlib.Path(__file__).parent


def logo(size: int, scale: float = 1.0, bg=NIGHT, radius_ratio: float | None = 0.22) -> Image.Image:
    S = 1024
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    if radius_ratio is None:
        d.rectangle([0, 0, S, S], fill=bg)
    else:
        d.rounded_rectangle([0, 0, S, S], radius=int(S * radius_ratio), fill=bg)

    c = S / 2
    r = 360 * scale
    w = int(44 * scale)
    # حلقة المؤقت: قوس مفتوح
    d.arc([c - r, c - r, c + r, c + r], start=-70, end=200, fill=GOLD, width=w)
    # نقطة بداية الحلقة
    a = math.radians(200)
    d.ellipse([c + r * math.cos(a) - w / 2, c + r * math.sin(a) - w / 2,
               c + r * math.cos(a) + w / 2, c + r * math.sin(a) + w / 2], fill=GOLD)

    # فقاعة كلام
    bw, bh = 470 * scale, 330 * scale
    box = [c - bw / 2, c - bh / 2 - 26 * scale, c + bw / 2, c + bh / 2 - 26 * scale]
    d.rounded_rectangle(box, radius=int(96 * scale), fill=PAPER)
    tail = [(c - 118 * scale, box[3] - 12 * scale), (c - 40 * scale, box[3] - 12 * scale),
            (c - 130 * scale, box[3] + 118 * scale)]
    d.polygon(tail, fill=PAPER)

    # شرطة مائلة: لا كلام
    d.line([c - 150 * scale, c + 92 * scale, c + 150 * scale, c - 152 * scale],
           fill=GOLD, width=int(52 * scale))

    return img.resize((size, size), Image.LANCZOS)


def main() -> None:
    (OUT / "pwa").mkdir(parents=True, exist_ok=True)
    (OUT / "resources").mkdir(parents=True, exist_ok=True)

    for s in (192, 512):
        logo(s).save(OUT / f"pwa/icon-{s}.png")
    logo(512, scale=0.62).save(OUT / "pwa/icon-maskable-512.png")
    logo(180).save(OUT / "pwa/apple-touch-icon.png")
    logo(32, radius_ratio=0.3).save(OUT / "pwa/favicon.png")

    # لمولّد أيقونات Capacitor
    logo(1024, radius_ratio=None).save(OUT / "resources/icon.png")
    for name in ("splash.png", "splash-dark.png"):
        canvas = Image.new("RGBA", (2732, 2732), NIGHT)
        mark = logo(1100, radius_ratio=None, bg=(0, 0, 0, 0))
        canvas.paste(mark, (816, 816), mark)
        canvas.save(OUT / "resources" / name)
    print("تم توليد الأيقونات")


if __name__ == "__main__":
    main()
