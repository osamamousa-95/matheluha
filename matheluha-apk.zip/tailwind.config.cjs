/** @type {import('tailwindcss').Config} */
const theme = require('./tailwind.theme.json');

module.exports = {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: theme },
  plugins: [],
};
